/**************************
 *Kevin Mody                                
 *CPSC2310 Fall 2020 Sec 001            
 *UserName: kmody                               
 *Instructor:  Dr. Yvon Feaster  
*************************/
#include <stdio.h>

int main(){
    int min = 0;
	int max = 10;
	for(int i = 0; i <= max; i++){
			printf("%d" , i);
	}

	printf("\n");
	return 0;

}